var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/supabase-proxy.ts
var supabase_proxy_exports = {};
__export(supabase_proxy_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(supabase_proxy_exports);
var handler = async (event) => {
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type, Authorization, apikey"
      },
      body: ""
    };
  }
  try {
    const SUPABASE_URL = process.env.SUPABASE_URL || "https://vkwhrbjkdznncjkzkiuo.supabase.co";
    const SUPABASE_PUBLIC_API_KEY = process.env.SUPABASE_PUBLIC_API_KEY || "sb_publishable_Ujfa9-Q184jwhMXRHt3NFQ_DGXvAcDs";
    const path = event.path.replace("/api/supabase/", "");
    const targetUrl = `${SUPABASE_URL}/${path}`;
    const response = await fetch(targetUrl, {
      method: event.httpMethod,
      headers: {
        "Content-Type": "application/json",
        "apikey": SUPABASE_PUBLIC_API_KEY,
        "Authorization": `Bearer ${SUPABASE_PUBLIC_API_KEY}`,
        ...Object.fromEntries(
          Object.entries(event.headers).filter(([key]) => !["host", "x-forwarded-for", "x-forwarded-proto"].includes(key.toLowerCase()))
        )
      },
      body: event.body || void 0
    });
    const responseBody = await response.text();
    return {
      statusCode: response.status,
      headers: {
        "Content-Type": response.headers.get("content-type") || "application/json",
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type, Authorization, apikey"
      },
      body: responseBody
    };
  } catch (error) {
    return {
      statusCode: 500,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*"
      },
      body: JSON.stringify({
        error: "Proxy error",
        message: error.message,
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
