import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type ContentItem = {
  id: string;
  title: string;
  content_text: string;
  source_url: string;
  content_hash: string;
  content_type: string;
  date_found: string;
  search_query: string;
  word_count: number;
  relevance_score: number;
  created_at: string;
};

export type MediaFile = {
  id: string;
  content_item_id: string;
  media_url: string;
  media_type: string;
  file_name: string;
  file_size: number;
  alt_text: string;
  created_at: string;
};

export type SearchSession = {
  id: string;
  search_query: string;
  search_provider: string;
  results_found: number;
  new_content_added: number;
  duplicates_found: number;
  created_at: string;
};